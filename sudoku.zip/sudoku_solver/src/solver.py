"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Gurjog Gambhir
ID:     190639190
Email:  gamb9190@mylaurier.ca
__updated__ = "2019-09-13"
------------------------------------------------------------------------
"""

board = [
    [7,8,0,4,0,0,1,2,0],
    [6,0,0,0,7,5,0,0,9],
    [0,0,0,6,0,1,0,7,8],
    [0,0,7,0,4,0,2,6,0],
    [0,0,1,0,5,0,9,3,0],
    [9,0,4,0,6,0,0,0,5],
    [0,7,0,3,0,0,0,1,2],
    [1,2,0,0,0,7,4,0,0],
    [0,4,9,2,0,6,0,0,7]
    ]

def solve(bo):
    
    board_Empty = find_empty(bo)
    
    if board_Empty == None:
        return True
    
    else:
        row, col = board_Empty
        
    for i in range(1,10):
        if valid(bo, i, (row,col)) == True:
            bo[row][col] = i
        
            solve_Recursive = solve(bo)
            
            if solve_Recursive == True:
                return True
            else:
                bo[row][col] = 0
                
    
    return False
            
    

def valid(bo, num, pos):
    for i in range(len(bo[0])):
        if bo[pos[0]][i] == num and pos[1] != i:
            return False
        
    for i in range(len(bo)):
        if bo[i][pos[1]] == num and pos[0] != i:
            return False
    
    box_row = pos[1] // 3
    box_col = pos[0] // 3
    
    for i in range(box_col * 3, box_col*3 + 3):
        for j in range(box_row * 3, box_row*3 + 3):
            if bo[i][j] == num and (i,j) != pos:
                return False
            
    
    return True
    
    
def print_board(bo):
    for i in range(len(bo)):
        if (i % 3 == 0) and i != 0:
            print("- - - - - - - - - - - - - ")
            
        for j in range(len(bo[0])):
            if (j % 3 == 0) and j != 0:
                print(" | ", end = "")
                
            if j == 8:
                print(bo[i][j])
                    
            else:
                print(str(bo[i][j]) + " ", end = "")
                    
                    


def find_empty(bo):
    for i in range(len(bo)):
        for j in range(len(bo[0])):
            if bo[i][j] == 0:
                return (i, j)


    return None


print_board(board)
solve(board)
print("_________________________")
print_board(board)